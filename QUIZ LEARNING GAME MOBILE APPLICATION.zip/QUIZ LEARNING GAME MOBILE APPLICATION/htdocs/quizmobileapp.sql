-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2024 at 02:00 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quizmobileapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `userName` varchar(30) NOT NULL,
  `userEmail` varchar(50) NOT NULL,
  `userUsername` varchar(20) NOT NULL,
  `userPassword` varchar(20) NOT NULL,
  `userAddress` varchar(100) NOT NULL,
  `userPostcode` varchar(5) NOT NULL,
  `userState` varchar(30) NOT NULL,
  `userPhone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `userName`, `userEmail`, `userUsername`, `userPassword`, `userAddress`, `userPostcode`, `userState`, `userPhone`) VALUES
(1, 'Aidiel Hussin', 'aidielhussin.3404@gmail.com', 'Aidiel', '1234.', 'No.1 Jalan Kedah Lama', '39568', 'Kedah', '0123343344'),
(3, 'Jemah', 'jemahBeauty12@gmail.com', 'Jemah', 'abcd', '', '', '', ''),
(4, 'Siti Humaira', 'maira123@gmail.com', 'Humaira', '1234', '', '', '', ''),
(7, 'Amadiman', 'madiman22@gmail.com', 'Amadi', '1234', 'Lo 43, Jalan Hitam', '65998', 'Putrajaya', '012598656'),
(8, 'Aidiel Adha', 'aidielAdha@gmail.com', 'Habsees', '1234', '', '', '', ''),
(9, 'Aisyah Habsee', 'habsee@gmail.com', 'Habsee', '1234', '23, Taman Gunung Serai', '59662', 'Kuala Lumpur', '0126596633'),
(10, 'Jemah Nazriyah', 'jemah123@gmail.com', 'Jemahs', '1234', '', '', '', ''),
(11, 'Aiman', 'aiman@gmail.com', 'Aiman', '1234', 'Jalan 2', '56789', 'Selangor', '019234567');

-- --------------------------------------------------------

--
-- Table structure for table `users_feedback`
--

CREATE TABLE `users_feedback` (
  `feedbackID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `feedback` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_feedback`
--

INSERT INTO `users_feedback` (`feedbackID`, `userID`, `feedback`) VALUES
(1, 1, 'Hello'),
(2, 1, 'Good Job!'),
(3, 2, 'Well done!'),
(11, 1, 'Need Improvement'),
(12, 1, 'Good Apps!'),
(13, 1, 'Dislike'),
(19, 7, 'Nice Application!'),
(20, 12, 'Hello World!'),
(21, 13, 'Good App!');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `userUsername` (`userUsername`);

--
-- Indexes for table `users_feedback`
--
ALTER TABLE `users_feedback`
  ADD PRIMARY KEY (`feedbackID`),
  ADD KEY `userID` (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users_feedback`
--
ALTER TABLE `users_feedback`
  MODIFY `feedbackID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
