<?php
/* include db connection file 
include("dbconn.php");

	//accept these data from MIT Interface
	$userName = $_POST['userName'];
	$userEmail = $_POST['userEmail'];
	$userUsername = $_POST['userUsername'];
	$userPassword = $_POST['userPassword'];
	
	$sql = "INSERT INTO users (userName, userEmail, userUsername, userPassword)
	VALUES ('" . $userName . "', '" . $userEmail . "', '" . $userUsername . "', '" . $userPassword . "')";

	mysqli_query($dbconn, $sql) or die ("Error: " . mysqli_error($dbconn));
	/* display a message 
	echo $sql;
	echo "Data has been saved";*/



/* include db connection file */
include("dbconn.php");

//accept these data from MIT Interface
$userName = $_POST['userName'];
$userEmail = $_POST['userEmail'];
$userUsername = $_POST['userUsername'];
$userPassword = $_POST['userPassword'];

//$userName = "Aidiel Adha";
//$userEmail = "aidielAdha@gmail.com";
//$userUsername = "Habsees";
//$userPassword = "1234";
	
	
$check_sql = "SELECT * FROM users WHERE userUsername = '$userUsername'";
$result = mysqli_query($dbconn, $check_sql);

if(mysqli_num_rows($result) > 0){
	echo "duplicate";
}
else{
	$sql = "INSERT INTO users (userName, userEmail, userUsername, userPassword)
	VALUES ('" . $userName . "', '" . $userEmail . "', '" . $userUsername . "', '" . $userPassword . "')";

	if(mysqli_query($dbconn, $sql)) {
		echo "Data has been saved";}
	else{
		echo "Error: " . mysqli_error($dbconn);
	}
}
?>