<?php
include("dbconn.php");
$userID = @$_POST['userID']; 
//$userID = 1;

// Prepare the SQL statement
$sql = "SELECT userAddress, userPostcode, userState, userPhone FROM users WHERE userID = ?";
$stmt = $dbconn->prepare($sql);

if ($stmt === false) {
    die('Prepare error: ' . $dbconn->error);
}

// Bind the userID parameter to the prepared statement
$stmt->bind_param('i', $userID);

// Execute the statement
$stmt->execute();

// Fetch the result
$res = $stmt->get_result();
$json = [];

while ($r = $res->fetch_array(MYSQLI_NUM)) {
    $json[] = $r;
}

echo json_encode($json, JSON_UNESCAPED_UNICODE);

// Free result and close connections
$stmt->free_result();
$stmt->close();
$dbconn->close();
?>
