<?php
include("dbconn.php");

$userUsername = $_POST['userUsername'];
$userPassword = $_POST['userPassword'];

$sql = "select * from users where userUsername = '$userUsername' and userPassword = '$userPassword'";
$query = mysqli_query($dbconn, $sql) or die ("Error: " . mysqli_error($dbconn));

if(mysqli_num_rows($query)>0)   //If username and password are matched
{
    while($rowr=mysqli_fetch_row($query))
    {
        $csvOutput[] = $rowr;
    }

    echo json_encode($csvOutput,JSON_UNESCAPED_UNICODE);
    exit;
}
else
{
    echo "error";
}

mysqli_free_result($query);
mysqli_close($dbconn);
?>