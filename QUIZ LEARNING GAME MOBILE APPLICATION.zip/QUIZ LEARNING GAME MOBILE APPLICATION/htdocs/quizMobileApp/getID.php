<?php
/* include db connection file*/
include("dbconn.php");
/* capture student number */
$userUsername = $_POST['userUsername='];
//$sid = 1120;
/* execute SQL statement */
$sql= "SELECT userID FROM users 
WHERE userUsername= '$userUsername'";

$query = mysqli_query($dbconn, $sql) or die ("Error: " . mysqli_error());
$numOfRows = mysqli_num_rows($query);
$query0 = mysqli_query($dbconn, "SHOW COLUMNS FROM USERS")

while($rowr= mysqli_fetch_row($query0))
{
	$csvOutput[] = $rowr;
	
}

echo json_encode($csvOutput,JSON_UNESCAPED_UNICODE);
exit;
?>
