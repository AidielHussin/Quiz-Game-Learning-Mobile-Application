<?php
/* include db connection file */
include("dbconn.php");

	//accept these data from MIT Interface
	$userID = $_POST['userID'];
	$feedback = $_POST['feedback'];
	
	//$userID = 1;
	//$feedback = "Good Job!";
	//$name = "aisyah mat jasin";
	//$number = 3333;
	//$username = "aisyahmat";
	//$password = "password";
	
	$sql = "INSERT INTO users_feedback (userID, feedback)
	VALUES (" . $userID . ", '" . $feedback . "')";
	mysqli_query($dbconn, $sql) or die ("Error: " . mysqli_error($dbconn));
	/* display a message */
	echo $sql;
	echo "Data has been saved";
?>