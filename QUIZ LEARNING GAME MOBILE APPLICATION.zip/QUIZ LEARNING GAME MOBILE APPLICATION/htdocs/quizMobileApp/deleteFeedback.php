<?php
include("dbconn.php");

$userID=@$_POST['userID']; 
//$userID=2;

$sql="delete from users where userID=$userID";

$res=mysqli_query($dbconn,$sql) or die(mysqli_error($dbconn));
if ($res==1) 
    echo "OK_DEL";

mysqli_close($dbconn);
?>