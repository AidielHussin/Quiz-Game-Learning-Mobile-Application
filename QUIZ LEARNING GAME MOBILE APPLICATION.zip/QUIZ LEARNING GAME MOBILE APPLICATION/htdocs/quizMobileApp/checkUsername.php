<?php
/*include ("dbconn.php");

if (isset($_POST['userUsername'])) {
    //$userUsername = $_POST['userUsername'];
    $userUsername=$_POST['userUsername'];
    //$userUsername="Aidiel";
    $query = "SELECT * FROM users WHERE userUsername='$userUsername'";
    $result = mysqli_query($dbconn, $query);
    if (mysqli_num_rows($result) > 0) {
        echo "taken";
    } else {
        echo "available";
    }
}*/


include("dbconn.php");

$user
?>