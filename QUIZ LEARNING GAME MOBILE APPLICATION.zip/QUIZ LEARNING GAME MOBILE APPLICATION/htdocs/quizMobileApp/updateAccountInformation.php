<?php
include("dbconn.php");

$userID=@$_POST['userID'];
$userAddress=@$_POST['userAddress'];
$userPostcode=@$_POST['userPostcode'];
$userState=@$_POST['userState'];
$userPhone=@$_POST['userPhone'];


/*$userID='3';
$userAddress='Jalan Batu';
$userPostcode='57000';
$userState='Selangor';
$userPhone='0123345566';*/

$sql="update users set userAddress='$userAddress', userPostcode='$userPostcode', userState='$userState', userPhone='$userPhone' where userID=$userID";
$res=mysqli_query($dbconn,$sql) or die(mysqli_error($dbconn));
if ($res===true) 
	echo "OK_EDIT"

?>